import Vue from 'vue'
import App from './App.vue'
import './assets/home.scss'
import './assets/slider.scss'
import 'ant-design-vue/dist/antd.css';
import $ from 'jquery';
import { Carousel } from 'ant-design-vue';
import VueMatchHeights from 'vue-match-heights';
Vue.config.productionTip = false

new Vue({
  render: h => h(App),
  mounted() {
    var rightSidebar = document.getElementById('right-menu')
    rightSidebar.style.display = 'none'
    $('.book-session').click((e) => {
      e.preventDefault();
      console.log(e)
      if (rightSidebar.style.display === 'none') {
        rightSidebar.style.display = 'block'
      }
      else {
        rightSidebar.style.display = 'none'
      }
    })
   
  },
}).$mount('#app')

Vue.use(Carousel);
Vue.use(VueMatchHeights, {
  disabled: [768], // Optional: default viewports widths to disabled resizing on. Can be overridden per usage
});
