<template>
  <div class="hello">
    <header>
      <div class="logo-box">
        <img src="../assets/img/logo.png" alt />
      </div>
      <div class="nav-bar">
        <ul>
          <li class="active">
            <a href="#">HOME</a>
          </li>
          <li>
            <a href="#">ABOUT US</a>

            <div class="sub-menu">
              <ul>
                <li>
                  <a href>About The Company</a>
                </li>
                <li>
                  <a href>About The chairman</a>
                </li>
              </ul>
            </div>
          </li>
          <li>
            <a href="#">INVESTMENTS</a>
            <div class="sub-menu">
              <ul>
                <li>
                  <a href>Our Investment</a>
                </li>
                <li>
                  <a href>Perroleom Sector</a>
                </li>
              </ul>
            </div>
          </li>
          <li>
            <a href="#">CARRERS</a>
          </li>
          <li>
            <a href="#">CONTACT US</a>
          </li>
        </ul>
        <div class="mobile-menu book-session">
          <img src="../assets/img/mb-btn.png" alt="">
        </div>

      </div>
    </header>

    <div class="mobile-menu-right" id="right-menu">
      <p class="book-session"> <img src="../assets/img/cr.png"> </p>
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">About Us</a></li>
        <li><a href="#">Investment</a></li>
        <li><a href="#">Carrirers</a></li>
        <li><a href="#">Contact Us</a></li>
      </ul>
    </div>

    <div class="banner" style></div>
      <!-- <div class="toget-sec">
        <div class="container">
          <h1>
            TOGETHER, WE
            <span>SUCCEED</span>
          </h1>
        </div>
      </div> -->
<!-- :autoPlay="true" -->
   <hooper  :playSpeed="2000">
    <slide>
       <div class="toget-sec">
        <div class="container">
          <h1>
            TOGETHER, WE
            <span>SUCCEED</span>
          </h1>
        </div>
      </div>
    </slide>
    <slide>
       <div class="toget-sec">
        <div class="container">
          <h1>
            TOGETHER, WE
            <span>SUCCEED</span>
          </h1>
        </div>
      </div>
    </slide>
  
    <hooper-navigation slot="hooper-addons"></hooper-navigation>
  </hooper>
    <div class="about">
      <h1>ABOUT</h1>
      <span></span>
      <p>AL Nasser Investment Company is a leading company in the investment field with a track record of excellence dating back over 40 years. Al Nasser Investment Company maintains a globally competitive, strategic portfolio across more than a dozen asset and sub-asset classes, including investments across both local and international markets. We have adopted ethical values and behaviors. Such values we follow as a group, within our businesses and also as individuals. A business idea is just another idea. However, an idea supported by clear logic, a robust business strategy, and a knowledgeable team is no longer an idea. This is a great investment venture that is worth pursuing now.</p>
    </div>

    <div class="about-image-box">
      <div class="about-image"></div>
    </div>

    <div class="fluid-box">
      <div class="fluid-left" >
        <p>Our Kingdom-wide reach has allowed us to build a dynamic atmosphere that brings fresh insights to any challenge and opportunity. As a result, we have acquired multiple and broad ranges of perceptions and experiences, which encouraged our strength and expanded our domestic and international investments. We are open to more investments and new opportunities. Our goal is to invest in new sectors and build a strong portfolio that will be well-known around the world. Also, we would like to have new business partners. We believe that diversity encourages performance. We don't just respect variation; we are consciously looking out and welcoming the difference.</p>
      </div>
      <div class="fluid-right">
        <div class="fluid-image"></div>
      </div>
    </div>

    <section class="contact">
      <div class="sec-padding">
        <div class="contact-head">
          <h1>CONTACT US</h1>
          <span></span>
        </div>
        <div class="map">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d7580750.020638232!2d72.55749969601706!3d21.913855825601452!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2s!4v1595683184745!5m2!1sen!2s"
            width="100%"
            height="450"
            frameborder="0"
            style="border:0; margin-bottom: 35px;"
            allowfullscreen
            aria-hidden="false"
            tabindex="0"
          ></iframe>
          <div class="contact-detail">
            <div class="contact-detail1">
              <div class="inqui">
                <h4>Inquiries</h4>
                <p>
                  Please use the below methods to contact for a
                  <br />proposal, inquiries, investment, or job application.
                </p>
              </div>
              <div class="contact-form">
                <h4>Contact Us</h4>
                <div class="formm">
                  <div class="detail">
                    <label>Enter Your Name</label>
                    <input type="text" name="Name" placeholder="Name" />
                  </div>
                  <div class="detail">
                    <label>Enter Your Email</label>
                    <input type="email" name="Email" placeholder="Email" />
                  </div>
                  <div class="detail">
                    <label>Enter Your Subject</label>
                    <input type="text" name="Subject" placeholder="Subject" />
                  </div>
                  <div class="detail">
                    <label>Enter your message</label>
                    <!-- <input type="text" name="Message" placeholder="Message" style="height: 150px;"> -->
                    <textarea placeholder="Message"></textarea>
                    <a href>Submit</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="contact-detail2">
              <div class="inqui">
                <h4>Head Office</h4>
                <p>
                  King's Road Tower, 10th Floor, 1009
                  <br />King Abdulaziz Road, Jeddah, Saudi Arabia
                </p>
              </div>
              <ul>
                <li>
                  <img src="../assets/img/lo.jpg"/>
                  <span>P.O. Box 2388 Jeddah 21436, Saudi Arabia</span>
                </li>
               <li>
<img src="../assets/img/phone.png" style="width: 21px;
    margin-top: 8px;"><span>P.O. Box 2388 Jeddah 21436, Saudi Arabia</span>
</li>
<li>
<img src="../assets/img/envo.png" style="width: 20px;
    margin-top: 7px;"><span>P.O. Box 2388 Jeddah 21436, Saudi Arabia</span>
</li>
              </ul>
              <div class="social">
                <h4>Stay In Touch</h4>
                <ul>
                <li><img src="../assets/img/link1.png"></li>
<li><img src="../assets/img/face.png"></li>
<li><img src="../assets/img/twitter.png"></li>
<li><img src="../assets/img/insta.png"></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="fotter">
      <div class="">
        <div class="logodiv">
          <img src="../assets/img/footer-logo.png" />
        </div>
        <div class="fotter-sec2">
          <div class="social">
            <ul>
              <li><img src="../assets/img/link.png"></li>
<li><img src="../assets/img/foter.png"></li>
<li><img src="../assets/img/twitter-logo.png"></li>
<li><img src="../assets/img/insta-1.png"></li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
import { Hooper, Slide,Navigation as HooperNavigation } from 'hooper';
import 'hooper/dist/hooper.css';
export default {
  name: "HelloWorld",
  components:{
    Hooper,
    Slide,
    HooperNavigation,
  },
  
  props: {
    msg: String,
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
@import "https://rawgit.com/kenwheeler/slick/master/slick/slick.css";
@import "https://rawgit.com/kenwheeler/slick/master/slick/slick-theme.css";
</style>

<style scoped>
/* For demo */
.fade-enter-active,
.fade-leave-active {
  transition: all 0.9s ease;
  overflow: hidden;
  visibility: visible;
  position: absolute;
  width:100%;
  opacity: 1;
}

.fade-enter,
.fade-leave-to {
  visibility: hidden;
  width:100%;
  opacity: 0;
}

/* img {
  height:600px;
  width:100%
} */

.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 40%;
  width: auto;
  padding: 16px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.7s ease;
  border-radius: 0 4px 4px 0;
  text-decoration: none;
  user-select: none;
}

.next {
  right: 0;
}

.prev {
  left: 0;
}

.prev:hover, .next:hover {
  background-color: rgba(0,0,0,0.9);
}
</style>
